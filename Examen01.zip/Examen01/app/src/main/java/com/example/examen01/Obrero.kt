package com.example.examen01


import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue

import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.layout.*

import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
@Composable
fun Pregunta1() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(top = 25.dp)
    ) {
        var horasTrabajadas by rememberSaveable { mutableStateOf("") }
        var resultado by rememberSaveable { mutableStateOf("") }

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.fillMaxSize()
        ) {
            Text(
                text = "CALCULAR SALARIO SEMANAL",
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth(),
                style = TextStyle(fontWeight = FontWeight.Bold, fontSize = 30.sp)
            )
            Obrero(16)
            OutlinedTextField(
                value = horasTrabajadas,
                onValueChange = { horasTrabajadas = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text(text = "Ingrese las horas trabajadas") },
                maxLines = 1,
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )
            Obrero(16)
            Button(
                onClick = {
                    val horas = horasTrabajadas.toIntOrNull()
                    if (horas != null) {
                        resultado = calcularSalario(horas)
                    } else {
                        resultado = "Por favor, ingrese un número válido de horas."
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(text = "CALCULAR")
            }
            Obrero(16)
            Text(
                text = resultado,
                style = TextStyle(fontWeight = FontWeight.Bold, color = Color.DarkGray)
            )
        }
    }
}

@Composable
fun Obrero(espacio: Int) {
    Spacer(modifier = Modifier.size(espacio.dp))
}

fun calcularSalario(horasTrabajadas: Int): String {
    val salarioBase = 16
    val salarioExtra = 20
    val horasBase = 40

    return if (horasTrabajadas <= horasBase) {
        "Salario semanal: $${salarioBase * horasTrabajadas}"
    } else {
        val salarioTotal = salarioBase * horasBase + salarioExtra * (horasTrabajadas - horasBase)
        "Salario semanal: $$salarioTotal"
    }
}